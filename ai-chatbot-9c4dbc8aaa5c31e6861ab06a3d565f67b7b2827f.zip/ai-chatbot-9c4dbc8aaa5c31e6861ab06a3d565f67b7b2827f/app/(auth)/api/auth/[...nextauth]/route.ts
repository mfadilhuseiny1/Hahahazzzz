export { GET, POST } from '@/app/(auth)/auth';
